# Senpai Launcher — Alpha 0.2.0

This is an Android Java starter project, not a complete Minecraft launcher.

Included:
- Local username field saved on-device
- Pojav JSON document picker and basic JSON reading
- GitHub Actions workflow to attempt a debug APK build

Not included yet:
- Minecraft version manifest/download/install
- Java runtime and game launching
- Fabric, Forge, Quilt installation
- Functional touch controls or Pojav control action conversion

Build with Android SDK and Gradle, or run the GitHub Actions workflow after uploading these files.
