package com.senpai.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.*;
import android.view.View;
import android.content.SharedPreferences;
import java.io.*;

public class MainActivity extends Activity {
    private static final int PICK_JSON = 41;
    private TextView status;
    private EditText username;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("senpai", MODE_PRIVATE);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(32, 40, 32, 32);

        TextView title = new TextView(this);
        title.setText("Senpai Launcher");
        title.setTextSize(28);
        page.addView(title);

        TextView note = new TextView(this);
        note.setText("Alpha 0.2.0 — starter build\nJava Minecraft launching is not implemented yet.");
        note.setTextSize(15);
        page.addView(note);

        username = new EditText(this);
        username.setSingleLine(true);
        username.setHint("Offline profile username");
        username.setText(prefs.getString("username", ""));
        page.addView(username);

        Button save = new Button(this);
        save.setText("Save profile");
        save.setOnClickListener(v -> {
            String name = username.getText().toString().trim();
            if (name.isEmpty()) { username.setError("Enter a username"); return; }
            prefs.edit().putString("username", name).apply();
            status.setText("Saved local profile: " + name);
        });
        page.addView(save);

        Button importControls = new Button(this);
        importControls.setText("Import Pojav control JSON");
        importControls.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("application/json");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_JSON);
        });
        page.addView(importControls);

        status = new TextView(this);
        status.setText("No control file selected.");
        status.setTextSize(14);
        page.addView(status);
        setContentView(page);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_JSON && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try (InputStream in = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[4096]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                String json = out.toString("UTF-8");
                if (!json.trim().startsWith("{")) throw new IOException("Not a JSON object");
                status.setText("JSON file imported and read (" + json.length() + " characters). Layout conversion is not implemented yet.");
            } catch (Exception e) {
                status.setText("Could not read JSON: " + e.getMessage());
            }
        }
    }
}
